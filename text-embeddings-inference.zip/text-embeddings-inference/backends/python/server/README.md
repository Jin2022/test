# Text Embeddings Inference Python gRPC Server

A Python gRPC server for Text Embeddings Inference

## Install

```shell
make install
```

## Run

```shell
make run-dev
```
